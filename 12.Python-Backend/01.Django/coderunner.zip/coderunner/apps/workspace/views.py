# apps/workspace/views.py
#
# All views use @api_view + @jwt_required decorator pattern.
# No class-based views — pure functions with decorators.

from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404

from apps.core.decorators import jwt_required, workspace_owner_required
from .models import Workspace, Snippet, Language
from .serializers import (
    WorkspaceSerializer, WorkspaceDetailSerializer,
    SnippetSerializer, LanguageSerializer
)


# ─────────────────────────────────────────────────────────────────────
#  LANGUAGES  (public read-only)
# ─────────────────────────────────────────────────────────────────────

@api_view(['GET'])
@permission_classes([AllowAny])
def language_list(request):
    """GET /api/v1/workspace/languages/ — list all supported languages."""
    languages = Language.objects.filter(is_active=True)
    serializer = LanguageSerializer(languages, many=True)
    return Response({'success': True, 'languages': serializer.data})


# ─────────────────────────────────────────────────────────────────────
#  WORKSPACES
# ─────────────────────────────────────────────────────────────────────

@api_view(['GET', 'POST'])
@jwt_required
def workspace_list_create(request):
    """
    GET  /api/v1/workspace/          — list my workspaces
    POST /api/v1/workspace/          — create a new workspace
    """
    if request.method == 'GET':
        workspaces = Workspace.objects.filter(owner=request.user)
        serializer = WorkspaceSerializer(workspaces, many=True)
        return Response({'success': True, 'workspaces': serializer.data})

    # POST — create
    serializer = WorkspaceSerializer(data=request.data)
    if not serializer.is_valid():
        return Response(
            {'success': False, 'errors': serializer.errors},
            status=status.HTTP_400_BAD_REQUEST
        )
    serializer.save(owner=request.user)  # inject owner from JWT
    return Response(
        {'success': True, 'workspace': serializer.data},
        status=status.HTTP_201_CREATED
    )


@api_view(['GET', 'PUT', 'PATCH', 'DELETE'])
@workspace_owner_required   # verifies JWT + ownership in one decorator
def workspace_detail(request, workspace_id):
    """
    GET    /api/v1/workspace/<id>/  — get workspace with all snippets
    PUT    /api/v1/workspace/<id>/  — full update
    PATCH  /api/v1/workspace/<id>/  — partial update
    DELETE /api/v1/workspace/<id>/  — delete workspace
    """
    workspace = request.workspace  # set by @workspace_owner_required

    if request.method == 'GET':
        serializer = WorkspaceDetailSerializer(workspace)
        return Response({'success': True, 'workspace': serializer.data})

    if request.method == 'DELETE':
        workspace.delete()
        return Response({'success': True, 'message': 'Workspace deleted.'})

    partial    = request.method == 'PATCH'
    serializer = WorkspaceSerializer(workspace, data=request.data, partial=partial)
    if not serializer.is_valid():
        return Response(
            {'success': False, 'errors': serializer.errors},
            status=status.HTTP_400_BAD_REQUEST
        )
    serializer.save()
    return Response({'success': True, 'workspace': serializer.data})


# ─────────────────────────────────────────────────────────────────────
#  SNIPPETS
# ─────────────────────────────────────────────────────────────────────

@api_view(['GET', 'POST'])
@jwt_required
def snippet_list_create(request, workspace_id):
    """
    GET  /api/v1/workspace/<id>/snippets/ — list snippets in workspace
    POST /api/v1/workspace/<id>/snippets/ — create a new snippet
    """
    workspace = get_object_or_404(Workspace, id=workspace_id, owner=request.user)

    if request.method == 'GET':
        snippets   = workspace.snippets.select_related('language').all()
        serializer = SnippetSerializer(snippets, many=True)
        return Response({'success': True, 'snippets': serializer.data})

    # POST — create snippet
    data = {**request.data, 'workspace': str(workspace.id)}
    serializer = SnippetSerializer(data=data, context={'request': request})
    if not serializer.is_valid():
        return Response(
            {'success': False, 'errors': serializer.errors},
            status=status.HTTP_400_BAD_REQUEST
        )
    serializer.save()
    return Response(
        {'success': True, 'snippet': serializer.data},
        status=status.HTTP_201_CREATED
    )


@api_view(['GET', 'PUT', 'PATCH', 'DELETE'])
@jwt_required
def snippet_detail(request, workspace_id, snippet_id):
    """
    GET    /api/v1/workspace/<ws_id>/snippets/<snip_id>/
    PUT    /api/v1/workspace/<ws_id>/snippets/<snip_id>/
    PATCH  /api/v1/workspace/<ws_id>/snippets/<snip_id>/
    DELETE /api/v1/workspace/<ws_id>/snippets/<snip_id>/
    """
    workspace = get_object_or_404(Workspace, id=workspace_id, owner=request.user)
    snippet   = get_object_or_404(Snippet,   id=snippet_id,   workspace=workspace)

    if request.method == 'GET':
        serializer = SnippetSerializer(snippet)
        return Response({'success': True, 'snippet': serializer.data})

    if request.method == 'DELETE':
        snippet.delete()
        return Response({'success': True, 'message': 'Snippet deleted.'})

    partial    = request.method == 'PATCH'
    serializer = SnippetSerializer(
        snippet, data=request.data, partial=partial, context={'request': request}
    )
    if not serializer.is_valid():
        return Response(
            {'success': False, 'errors': serializer.errors},
            status=status.HTTP_400_BAD_REQUEST
        )
    serializer.save()
    return Response({'success': True, 'snippet': serializer.data})
