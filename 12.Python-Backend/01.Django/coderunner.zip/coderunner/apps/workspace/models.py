# apps/workspace/models.py
import uuid
from django.db import models
from django.conf import settings


class Language(models.Model):
    """
    Supported programming languages.
    Judge0 identifies languages by integer ID.
    Seed this table via a management command or fixture.
    """
    name       = models.CharField(max_length=50, unique=True)   # e.g. "Python 3"
    slug       = models.SlugField(unique=True)                   # e.g. "python3"
    judge0_id  = models.PositiveIntegerField(unique=True)        # e.g. 71
    version    = models.CharField(max_length=30, blank=True)
    logo_url   = models.URLField(blank=True)
    is_active  = models.BooleanField(default=True)

    class Meta:
        db_table  = 'languages'
        ordering  = ['name']

    def __str__(self):
        return f'{self.name} (judge0_id={self.judge0_id})'


class Workspace(models.Model):
    """
    A workspace is a named collection of code snippets for one user.
    Think of it like a project folder.
    """
    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    owner       = models.ForeignKey(
                      settings.AUTH_USER_MODEL,
                      on_delete=models.CASCADE,
                      related_name='workspaces'
                  )
    name        = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    is_public   = models.BooleanField(default=False)
    created_at  = models.DateTimeField(auto_now_add=True)
    updated_at  = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'workspaces'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.name} ({self.owner.username})'


class Snippet(models.Model):
    """
    A code snippet inside a workspace.
    Stores the source code, chosen language, and the last run result.
    """
    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    workspace   = models.ForeignKey(
                      Workspace,
                      on_delete=models.CASCADE,
                      related_name='snippets'
                  )
    language    = models.ForeignKey(
                      Language,
                      on_delete=models.PROTECT,
                      related_name='snippets'
                  )
    title       = models.CharField(max_length=150, default='Untitled snippet')
    source_code = models.TextField()
    stdin       = models.TextField(blank=True, help_text='Standard input for the program')
    created_at  = models.DateTimeField(auto_now_add=True)
    updated_at  = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'snippets'
        ordering = ['-updated_at']

    def __str__(self):
        return f'{self.title} [{self.language.slug}]'
