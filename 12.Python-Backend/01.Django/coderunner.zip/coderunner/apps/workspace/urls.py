# apps/workspace/urls.py
from django.urls import path
from . import views

urlpatterns = [
    # Languages
    path('languages/',                                  views.language_list,          name='language-list'),

    # Workspaces
    path('',                                            views.workspace_list_create,  name='workspace-list-create'),
    path('<uuid:workspace_id>/',                        views.workspace_detail,        name='workspace-detail'),

    # Snippets (nested under workspace)
    path('<uuid:workspace_id>/snippets/',               views.snippet_list_create,    name='snippet-list-create'),
    path('<uuid:workspace_id>/snippets/<uuid:snippet_id>/', views.snippet_detail,     name='snippet-detail'),
]
