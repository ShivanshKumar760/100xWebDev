# coderunner/settings.py
from pathlib import Path
from decouple import config
from datetime import timedelta

BASE_DIR = Path(__file__).resolve().parent.parent

# ─────────────────────────────────────────────
#  SECURITY
# ─────────────────────────────────────────────
SECRET_KEY = config('SECRET_KEY', default='change-me-in-production')
DEBUG      = config('DEBUG', default=False, cast=bool)
ALLOWED_HOSTS = config('ALLOWED_HOSTS', default='*').split(',')

# ─────────────────────────────────────────────
#  APPS
# ─────────────────────────────────────────────
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    # third-party
    'rest_framework',
    'rest_framework_simplejwt',
    'rest_framework_simplejwt.token_blacklist',
    'corsheaders',

    # local
    'apps.authentication',
    'apps.workspace',
    'apps.execution',
]

# ─────────────────────────────────────────────
#  MIDDLEWARE
# ─────────────────────────────────────────────
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'corsheaders.middleware.CorsMiddleware',          # must be high up
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'coderunner.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'coderunner.wsgi.application'

# ─────────────────────────────────────────────
#  DATABASE  (PostgreSQL via env vars)
# ─────────────────────────────────────────────
DATABASES = {
    'default': {
        'ENGINE':   'django.db.backends.postgresql',
        'NAME':     config('DB_NAME',     default='coderunner'),
        'USER':     config('DB_USER',     default='postgres'),
        'PASSWORD': config('DB_PASSWORD', default='postgres'),
        'HOST':     config('DB_HOST',     default='db'),   # docker service name
        'PORT':     config('DB_PORT',     default='5432'),
    }
}

# ─────────────────────────────────────────────
#  AUTH
# ─────────────────────────────────────────────
AUTH_USER_MODEL = 'authentication.User'   # our custom user model

AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

# ─────────────────────────────────────────────
#  DJANGO REST FRAMEWORK
# ─────────────────────────────────────────────
REST_FRAMEWORK = {
    # All endpoints require JWT auth by default
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ),
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.IsAuthenticated',
    ),
    'DEFAULT_RENDERER_CLASSES': (
        'rest_framework.renderers.JSONRenderer',
    ),
    'DEFAULT_PARSER_CLASSES': (
        'rest_framework.parsers.JSONParser',
    ),
    'EXCEPTION_HANDLER': 'apps.core.exceptions.custom_exception_handler',
}

# ─────────────────────────────────────────────
#  SIMPLE JWT  — token lifetimes + algorithm
# ─────────────────────────────────────────────
SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME':         timedelta(minutes=60),
    'REFRESH_TOKEN_LIFETIME':        timedelta(days=7),
    'ROTATE_REFRESH_TOKENS':         True,   # new refresh token on every refresh
    'BLACKLIST_AFTER_ROTATION':      True,   # old refresh token is blacklisted
    'UPDATE_LAST_LOGIN':             True,

    'ALGORITHM':                     'HS256',
    'SIGNING_KEY':                   SECRET_KEY,

    # What the token payload claims are called
    'AUTH_HEADER_TYPES':             ('Bearer',),
    'AUTH_HEADER_NAME':              'HTTP_AUTHORIZATION',
    'USER_ID_FIELD':                 'id',
    'USER_ID_CLAIM':                 'user_id',

    'TOKEN_OBTAIN_SERIALIZER':       'apps.authentication.serializers.CustomTokenObtainPairSerializer',
}

# ─────────────────────────────────────────────
#  CORS (allow React dev server)
# ─────────────────────────────────────────────
CORS_ALLOWED_ORIGINS = config(
    'CORS_ALLOWED_ORIGINS',
    default='http://localhost:3000,http://127.0.0.1:3000'
).split(',')

CORS_ALLOW_HEADERS = [
    'accept', 'accept-encoding', 'authorization',
    'content-type', 'origin', 'user-agent', 'x-csrftoken',
]

# ─────────────────────────────────────────────
#  JUDGE0 API
# ─────────────────────────────────────────────
JUDGE0_API_URL  = config('JUDGE0_API_URL',  default='https://judge0-ce.p.rapidapi.com')
JUDGE0_API_KEY  = config('JUDGE0_API_KEY',  default='')
JUDGE0_API_HOST = config('JUDGE0_API_HOST', default='judge0-ce.p.rapidapi.com')

# ─────────────────────────────────────────────
#  MISC
# ─────────────────────────────────────────────
LANGUAGE_CODE = 'en-us'
TIME_ZONE     = 'UTC'
USE_I18N      = True
USE_TZ        = True

STATIC_URL  = '/static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
