import aio_pika
import os
from typing import Optional

RABBITMQ_URL = os.getenv("RABBITMQ_URL", "amqp://guest:guest@rabbitmq:5672/")

TOPIC_EXCHANGE = "job.input"
FANOUT_EXCHANGE = "job.completed"

QUEUE_PYTHON = "job.python"
QUEUE_JS = "job.js"
QUEUE_CPP = "job.cpp"

QUEUE_RESULT = "result-service.job.completed"
QUEUE_NOTIFIER = "notifier-service.job.completed"
QUEUE_BILLING = "billing-service.job.completed"
QUEUE_ANALYTICS = "analytics-service.job.completed"

_connection: Optional[aio_pika.RobustConnection] = None


async def get_connection() -> aio_pika.RobustConnection:
    global _connection
    if _connection is None or _connection.is_closed:
        _connection = await aio_pika.connect_robust(RABBITMQ_URL)
    return _connection


async def get_channel() -> aio_pika.Channel:
    conn = await get_connection()
    return await conn.channel()


async def declare_topic_exchange(channel: aio_pika.Channel) -> aio_pika.Exchange:
    return await channel.declare_exchange(
        TOPIC_EXCHANGE, aio_pika.ExchangeType.TOPIC, durable=True
    )


async def declare_fanout_exchange(channel: aio_pika.Channel) -> aio_pika.Exchange:
    return await channel.declare_exchange(
        FANOUT_EXCHANGE, aio_pika.ExchangeType.FANOUT, durable=True
    )


async def declare_language_queues(channel: aio_pika.Channel):
    exchange = await declare_topic_exchange(channel)
    for queue_name, routing_key in [
        (QUEUE_PYTHON, "job.python"),
        (QUEUE_JS, "job.js"),
        (QUEUE_CPP, "job.cpp"),
    ]:
        queue = await channel.declare_queue(queue_name, durable=True)
        await queue.bind(exchange, routing_key=routing_key)
    return exchange


async def declare_fanout_consumer_queue(channel: aio_pika.Channel, queue_name: str):
    exchange = await declare_fanout_exchange(channel)
    queue = await channel.declare_queue(queue_name, durable=True)
    await queue.bind(exchange, routing_key="")
    return queue
