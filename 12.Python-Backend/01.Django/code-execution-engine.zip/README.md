# Code Execution Engine

A production-grade microservice platform for secure, multi-language code execution.
Built with FastAPI, RabbitMQ (topic + fanout exchanges), Docker, and Kubernetes.

## Architecture

```
Client → API Gateway → Submission Service
                             │
                     [Topic Exchange]        ← routes by language (job.python / job.js / job.cpp)
                    ┌────────┼────────┐
               Python Q    JS Q    C++ Q
                    └────────┼────────┘
                     Executor Workers        ← Docker sandboxed subprocess (seccomp + cgroups)
                             │
                     [Fanout Exchange]       ← broadcasts job.completed to all consumers
              ┌──────┬───────┼───────┬──────┐
         Result Svc Notifier Billing Analytics
         (PG+Redis) (WS)    (usage)  (metrics)
```

## Services

| Service            | Port | Description                                      |
|--------------------|------|--------------------------------------------------|
| api-gateway        | 8000 | Auth, rate-limiting, request routing             |
| submission-service | 8001 | Job persistence + publishes to topic exchange    |
| result-service     | 8002 | Stores results in PostgreSQL + Redis, REST API   |
| notifier-service   | 8003 | WebSocket push notifications                     |
| billing-service    | 8004 | Usage metering per user                          |
| analytics-service  | 8005 | Runtime metrics and statistics                   |
| worker-python      | —    | Executes Python code in sandboxed subprocess     |
| worker-js          | —    | Executes JavaScript code via Node.js             |
| worker-cpp         | —    | Compiles and runs C++ via GCC                    |

## Quick Start (Docker Compose)

```bash
# Start everything
docker compose up --build

# Submit a Python job
curl -X POST http://localhost:8000/api/v1/jobs \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer user-123" \
  -d '{"language": "python", "code": "print(\"Hello World\")", "timeout_seconds": 10}'

# Poll for result (use job_id from above response)
curl http://localhost:8000/api/v1/jobs/<job_id>

# Connect via WebSocket for live push
wscat -c ws://localhost:8003/ws/user-123

# RabbitMQ Management UI
open http://localhost:15672   # guest / guest
```

## Kubernetes Deployment

```bash
# Apply in order
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/secrets/
kubectl apply -f k8s/configmaps/
kubectl apply -f k8s/deployments/infrastructure.yaml
# Wait for infra to be ready
kubectl wait --for=condition=ready pod -l app=rabbitmq -n code-exec --timeout=60s
kubectl apply -f k8s/deployments/
kubectl apply -f k8s/hpa/
kubectl apply -f k8s/networkpolicies/
```

## RabbitMQ Exchange Design

### Topic Exchange — `job.input`
Routes incoming jobs to the correct language worker queue.
- `job.python` → Python worker queue
- `job.js`     → JS worker queue
- `job.cpp`    → C++ worker queue

### Fanout Exchange — `job.completed`
Broadcasts every completed job result to all downstream consumers simultaneously.
Each consumer has its own durable queue and processes independently:
- `result-service.job.completed`   → writes PostgreSQL + Redis
- `notifier-service.job.completed` → WebSocket push
- `billing-service.job.completed`  → usage metering
- `analytics-service.job.completed`→ runtime metrics

## Security

- Executor workers run as non-root (UID 1000)
- subprocess `resource.setrlimit` limits CPU and memory per execution
- `NetworkPolicy` restricts executor pods: only RabbitMQ egress allowed
- No executor pod can make outbound HTTP calls

## Environment Variables

All services read from the `app-config` ConfigMap:

| Variable               | Default                                              |
|------------------------|------------------------------------------------------|
| `RABBITMQ_URL`         | `amqp://guest:guest@rabbitmq:5672/`                  |
| `DATABASE_URL`         | `postgresql://postgres:password@postgres:5432/codeexec` |
| `REDIS_URL`            | `redis://redis:6379`                                 |
| `SUBMISSION_SERVICE_URL` | `http://submission-service:8001`                   |
| `RESULT_SERVICE_URL`   | `http://result-service:8002`                         |
| `WORKER_LANGUAGE`      | `python` (set per worker deployment)                 |
