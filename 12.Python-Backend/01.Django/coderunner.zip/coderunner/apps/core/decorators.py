# apps/core/decorators.py
#
# This module provides function-level decorators that work on top of
# DRF's JWT authentication.  Use them exactly like Django's own
# @login_required — but for API views.
#
# How it works (plain English):
#   1. React sends:  Authorization: Bearer <access_token>
#   2. The decorator intercepts the view before it runs.
#   3. It calls JWTAuthentication().authenticate(request) which:
#        a. Reads the header
#        b. Base64-decodes the token payload
#        c. Verifies the HMAC-SHA256 signature with SECRET_KEY
#        d. Checks the expiry claim (exp) hasn't passed
#        e. Returns (user, validated_token) or raises AuthenticationFailed
#   4. If valid  → request.user is set → real view runs
#   5. If invalid → 401 is returned immediately, view never runs

import functools
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError
from rest_framework.response import Response
from rest_framework import status


def jwt_required(view_func):
    """
    Decorator for @api_view function-based views.
    Enforces JWT authentication and attaches the user to request.

    Usage:
        @api_view(['GET'])
        @jwt_required
        def my_view(request):
            return Response({'user': request.user.email})
    """
    @functools.wraps(view_func)
    def wrapper(request, *args, **kwargs):
        authenticator = JWTAuthentication()
        try:
            # Returns (user, token) tuple or None if no header present
            result = authenticator.authenticate(request)
            if result is None:
                return Response(
                    {'success': False, 'error': 'Authentication credentials were not provided.'},
                    status=status.HTTP_401_UNAUTHORIZED
                )
            user, token = result
            request.user           = user
            request.auth           = token        # raw validated token object
            request.token_payload  = token.payload  # dict of JWT claims
        except (InvalidToken, TokenError) as e:
            return Response(
                {'success': False, 'error': str(e), 'detail': 'Token is invalid or expired.'},
                status=status.HTTP_401_UNAUTHORIZED
            )

        return view_func(request, *args, **kwargs)

    return wrapper


def jwt_optional(view_func):
    """
    Same as jwt_required but doesn't reject unauthenticated requests.
    request.user will be AnonymousUser if no token is present.
    Useful for endpoints that behave differently for auth vs anon users.
    """
    @functools.wraps(view_func)
    def wrapper(request, *args, **kwargs):
        authenticator = JWTAuthentication()
        try:
            result = authenticator.authenticate(request)
            if result is not None:
                user, token = result
                request.user          = user
                request.auth          = token
                request.token_payload = token.payload
        except (InvalidToken, TokenError):
            pass   # anonymous — let the view decide what to do

        return view_func(request, *args, **kwargs)

    return wrapper


def workspace_owner_required(view_func):
    """
    Extends jwt_required: also checks that the workspace in the URL
    belongs to the authenticated user.

    Assumes the URL captures <int:workspace_id>.
    Attaches request.workspace for convenience.

    Usage:
        @api_view(['GET'])
        @workspace_owner_required
        def my_view(request, workspace_id):
            ws = request.workspace   # already fetched and verified
    """
    @functools.wraps(view_func)
    @jwt_required
    def wrapper(request, *args, **kwargs):
        from apps.workspace.models import Workspace
        from django.shortcuts import get_object_or_404

        workspace_id = kwargs.get('workspace_id')
        workspace    = get_object_or_404(Workspace, id=workspace_id)

        if workspace.owner != request.user:
            return Response(
                {'success': False, 'error': 'You do not own this workspace.'},
                status=status.HTTP_403_FORBIDDEN
            )
        request.workspace = workspace
        return view_func(request, *args, **kwargs)

    return wrapper
