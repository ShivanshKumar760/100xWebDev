"""
Analytics Service — consumes job.completed fanout, tracks runtime metrics.
"""
from fastapi import FastAPI
from contextlib import asynccontextmanager
import aio_pika
import asyncpg
import asyncio
import json
import os
import sys
from datetime import datetime

sys.path.insert(0, "/app")
from shared.rabbitmq import get_channel, declare_fanout_consumer_queue, QUEUE_ANALYTICS

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:password@postgres:5432/codeexec")
db_pool = None


async def consume_analytics():
    channel = await get_channel()
    await channel.set_qos(prefetch_count=10)
    queue = await declare_fanout_consumer_queue(channel, QUEUE_ANALYTICS)

    async with queue.iterator() as q:
        async for message in q:
            async with message.process():
                event = json.loads(message.body.decode())
                try:
                    async with db_pool.acquire() as conn:
                        await conn.execute(
                            """INSERT INTO analytics_events
                               (job_id, user_id, language, status, execution_ms, exit_code, recorded_at)
                               VALUES ($1,$2,$3,$4,$5,$6,$7)
                               ON CONFLICT (job_id) DO NOTHING""",
                            event["job_id"], event["user_id"], event["language"],
                            event["status"], event.get("execution_ms", 0),
                            event.get("exit_code", 0), datetime.utcnow(),
                        )
                    print(f"[analytics] Tracked job {event['job_id']}")
                except Exception as e:
                    print(f"[analytics] Error: {e}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    global db_pool
    db_pool = await asyncpg.create_pool(DATABASE_URL)
    async with db_pool.acquire() as conn:
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS analytics_events (
                id SERIAL PRIMARY KEY,
                job_id TEXT UNIQUE NOT NULL,
                user_id TEXT NOT NULL,
                language TEXT NOT NULL,
                status TEXT NOT NULL,
                execution_ms INT DEFAULT 0,
                exit_code INT DEFAULT 0,
                recorded_at TIMESTAMPTZ DEFAULT NOW()
            )
        """)
    asyncio.create_task(consume_analytics())
    yield
    if db_pool:
        await db_pool.close()


app = FastAPI(title="Analytics Service", lifespan=lifespan)


@app.get("/health")
async def health():
    return {"status": "ok", "service": "analytics-service"}


@app.get("/stats")
async def get_stats():
    async with db_pool.acquire() as conn:
        rows = await conn.fetch("""
            SELECT language,
                   COUNT(*) as total,
                   AVG(execution_ms) as avg_ms,
                   SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) as success,
                   SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) as failed,
                   SUM(CASE WHEN status='timeout' THEN 1 ELSE 0 END) as timeouts
            FROM analytics_events GROUP BY language
        """)
    return {"stats": [dict(r) for r in rows]}
