from pydantic import BaseModel, Field
from typing import Optional, Literal
from datetime import datetime
import uuid


class JobSubmitRequest(BaseModel):
    language: Literal["python", "js", "cpp"]
    code: str
    timeout_seconds: int = Field(default=10, ge=1, le=60)
    memory_limit_mb: int = Field(default=128, ge=16, le=512)


class JobResponse(BaseModel):
    job_id: str
    status: str
    language: str
    created_at: datetime


class JobResult(BaseModel):
    job_id: str
    user_id: str
    language: str
    stdout: str = ""
    stderr: str = ""
    exit_code: int = 0
    execution_ms: int = 0
    memory_used_mb: float = 0.0
    status: Literal["completed", "failed", "timeout"]
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class JobRecord(BaseModel):
    job_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    language: str
    code: str
    status: str = "pending"
    timeout_seconds: int = 10
    memory_limit_mb: int = 128
    created_at: datetime = Field(default_factory=datetime.utcnow)
