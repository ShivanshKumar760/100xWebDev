# apps/workspace/serializers.py
from rest_framework import serializers
from .models import Workspace, Snippet, Language


class LanguageSerializer(serializers.ModelSerializer):
    class Meta:
        model  = Language
        fields = ['id', 'name', 'slug', 'judge0_id', 'version', 'logo_url']


class SnippetSerializer(serializers.ModelSerializer):
    language_detail = LanguageSerializer(source='language', read_only=True)

    class Meta:
        model  = Snippet
        fields = [
            'id', 'workspace', 'language', 'language_detail',
            'title', 'source_code', 'stdin', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at', 'language_detail']

    def validate_workspace(self, workspace):
        """Ensure the snippet belongs to a workspace owned by the requesting user."""
        request = self.context.get('request')
        if request and workspace.owner != request.user:
            raise serializers.ValidationError('You do not own this workspace.')
        return workspace


class WorkspaceSerializer(serializers.ModelSerializer):
    owner_username = serializers.ReadOnlyField(source='owner.username')
    snippet_count  = serializers.SerializerMethodField()

    class Meta:
        model  = Workspace
        fields = [
            'id', 'name', 'description', 'is_public',
            'owner_username', 'snippet_count', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'owner_username', 'snippet_count', 'created_at', 'updated_at']

    def get_snippet_count(self, obj):
        return obj.snippets.count()


class WorkspaceDetailSerializer(WorkspaceSerializer):
    """Full workspace with all its snippets."""
    snippets = SnippetSerializer(many=True, read_only=True)

    class Meta(WorkspaceSerializer.Meta):
        fields = WorkspaceSerializer.Meta.fields + ['snippets']
