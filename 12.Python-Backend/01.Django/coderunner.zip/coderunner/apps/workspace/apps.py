# apps/workspace/apps.py
from django.apps import AppConfig

class WorkspaceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name  = 'apps.workspace'
    label = 'workspace'
