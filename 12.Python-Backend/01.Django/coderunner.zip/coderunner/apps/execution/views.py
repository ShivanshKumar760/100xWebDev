# apps/execution/views.py
#
# The most important file in the project.
# POST /api/v1/execution/run/ → validates JWT → validates request →
#   calls Judge0 → saves result → returns output to client.

from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from decimal import Decimal, InvalidOperation

from apps.core.decorators import jwt_required
from apps.workspace.models import Snippet
from .models import ExecutionResult
from .serializers import ExecuteRequestSerializer, ExecutionResultSerializer
from . import judge0


# ─────────────────────────────────────────────────────────────────────
#  POST /api/v1/execution/run/
#  PROTECTED — requires JWT
# ─────────────────────────────────────────────────────────────────────
@api_view(['POST'])
@jwt_required
def run_code(request):
    """
    Execute code via Judge0.

    Two modes:

    Mode 1 — Ad-hoc (raw code from editor):
        {
            "source_code": "print('hello')",
            "language_id": 71,
            "stdin": ""          (optional)
        }

    Mode 2 — Saved snippet:
        {
            "snippet_id": "<uuid>"
        }

    Response:
        {
            "success": true,
            "result": {
                "id": "...",
                "stdout": "hello\\n",
                "stderr": "",
                "status_id": 3,
                "status_desc": "Accepted",
                "time_seconds": "0.045",
                "memory_kb": 9012,
                "is_success": true,
                "output": "hello\\n"
            }
        }
    """
    # ── Step 1: Validate the request body ────────────────────────────
    req_serializer = ExecuteRequestSerializer(data=request.data)
    if not req_serializer.is_valid():
        return Response(
            {'success': False, 'errors': req_serializer.errors},
            status=status.HTTP_400_BAD_REQUEST
        )

    data = req_serializer.validated_data

    # ── Step 2: Resolve source code + language ────────────────────────
    snippet     = None
    source_code = data.get('source_code', '')
    language_id = data.get('language_id')
    stdin       = data.get('stdin', '')

    if data.get('snippet_id'):
        # Mode 2: run a saved snippet — must belong to this user
        snippet     = get_object_or_404(
                          Snippet,
                          id=data['snippet_id'],
                          workspace__owner=request.user
                      )
        source_code = snippet.source_code
        language_id = snippet.language.judge0_id
        stdin       = snippet.stdin

    # ── Step 3: Send to Judge0 ────────────────────────────────────────
    judge0_result = judge0.submit_code(
        source_code=source_code,
        language_id=language_id,
        stdin=stdin,
    )

    # ── Step 4: Parse metrics from Judge0 response ────────────────────
    time_seconds = None
    if judge0_result.get('time'):
        try:
            time_seconds = Decimal(str(judge0_result['time']))
        except InvalidOperation:
            pass

    memory_kb = judge0_result.get('memory')  # already an int or None

    # ── Step 5: Persist the result in PostgreSQL ──────────────────────
    execution = ExecutionResult.objects.create(
        user           = request.user,
        snippet        = snippet,
        source_code    = source_code,
        language_id    = language_id,
        stdin          = stdin,
        judge0_token   = judge0_result.get('token', ''),
        stdout         = judge0_result.get('stdout', ''),
        stderr         = judge0_result.get('stderr', ''),
        compile_output = judge0_result.get('compile_output', ''),
        message        = judge0_result.get('message', ''),
        status_id      = judge0_result.get('status_id', 13),
        status_desc    = judge0_result.get('status_desc', 'Internal Error'),
        time_seconds   = time_seconds,
        memory_kb      = memory_kb,
    )

    # ── Step 6: Return result to client ──────────────────────────────
    result_serializer = ExecutionResultSerializer(execution)
    return Response(
        {'success': True, 'result': result_serializer.data},
        status=status.HTTP_200_OK
    )


# ─────────────────────────────────────────────────────────────────────
#  GET /api/v1/execution/history/
#  PROTECTED — returns the last 50 runs for this user
# ─────────────────────────────────────────────────────────────────────
@api_view(['GET'])
@jwt_required
def execution_history(request):
    """
    Returns the last 50 executions for the authenticated user.
    Supports ?snippet_id=<uuid> to filter by snippet.
    """
    executions = ExecutionResult.objects.filter(user=request.user)

    snippet_id = request.query_params.get('snippet_id')
    if snippet_id:
        executions = executions.filter(snippet__id=snippet_id)

    executions = executions.select_related('snippet')[:50]
    serializer = ExecutionResultSerializer(executions, many=True)
    return Response({'success': True, 'history': serializer.data})


# ─────────────────────────────────────────────────────────────────────
#  GET /api/v1/execution/<id>/
#  PROTECTED — get a single execution result
# ─────────────────────────────────────────────────────────────────────
@api_view(['GET'])
@jwt_required
def execution_detail(request, execution_id):
    execution = get_object_or_404(
        ExecutionResult, id=execution_id, user=request.user
    )
    serializer = ExecutionResultSerializer(execution)
    return Response({'success': True, 'result': serializer.data})


# ─────────────────────────────────────────────────────────────────────
#  GET /api/v1/execution/stats/
#  PROTECTED — aggregate stats for the user's dashboard
# ─────────────────────────────────────────────────────────────────────
@api_view(['GET'])
@jwt_required
def execution_stats(request):
    """
    Returns quick stats:
        total runs, successful runs, failed runs, most-used language.
    """
    from django.db.models import Count

    qs = ExecutionResult.objects.filter(user=request.user)

    total      = qs.count()
    successful = qs.filter(status_id=3).count()
    failed     = total - successful

    top_lang = (
        qs.values('language_id')
          .annotate(count=Count('language_id'))
          .order_by('-count')
          .first()
    )

    return Response({
        'success': True,
        'stats': {
            'total_runs':      total,
            'successful_runs': successful,
            'failed_runs':     failed,
            'top_language_id': top_lang['language_id'] if top_lang else None,
        }
    })
