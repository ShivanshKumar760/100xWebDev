# apps/authentication/views.py
#
# ALL views here use the @api_view decorator pattern (function-based views).
# Public endpoints (register, login, refresh) are open.
# Protected endpoints (/me, /logout) use our custom @jwt_required decorator.

from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.exceptions import TokenError, InvalidToken
from django.contrib.auth import get_user_model

from apps.core.decorators import jwt_required
from .serializers import RegisterSerializer, UserSerializer, CustomTokenObtainPairSerializer

User = get_user_model()


# ─────────────────────────────────────────────────────────────────────
#  POST /api/v1/auth/register/
#  Public — no auth needed
# ─────────────────────────────────────────────────────────────────────
@api_view(['POST'])
@permission_classes([AllowAny])
def register(request):
    """
    Create a new user account and immediately return JWT tokens
    so the user is logged in right after sign-up.

    Request body:
        { "email": "...", "username": "...", "password": "...", "confirm_password": "..." }

    Response:
        { "success": true, "user": {...}, "tokens": { "access": "...", "refresh": "..." } }
    """
    serializer = RegisterSerializer(data=request.data)

    if not serializer.is_valid():
        return Response(
            {'success': False, 'errors': serializer.errors},
            status=status.HTTP_400_BAD_REQUEST
        )

    user = serializer.save()

    # Generate JWT pair for the newly created user
    refresh = RefreshToken.for_user(user)
    # Add our custom claims (email, username) to the token payload
    refresh['email']    = user.email
    refresh['username'] = user.username
    refresh['is_staff'] = user.is_staff

    return Response(
        {
            'success': True,
            'message': 'Account created successfully.',
            'user':    UserSerializer(user).data,
            'tokens': {
                'access':  str(refresh.access_token),
                'refresh': str(refresh),
            }
        },
        status=status.HTTP_201_CREATED
    )


# ─────────────────────────────────────────────────────────────────────
#  POST /api/v1/auth/login/
#  Public — no auth needed
# ─────────────────────────────────────────────────────────────────────
@api_view(['POST'])
@permission_classes([AllowAny])
def login(request):
    """
    Validate email + password, return JWT access + refresh tokens.

    Request body:
        { "email": "...", "password": "..." }

    Internally uses CustomTokenObtainPairSerializer which:
      1. Checks email exists in DB
      2. Verifies bcrypt/PBKDF2 hash of the password
      3. If OK → generates access token (60 min) + refresh token (7 days)
      4. Embeds custom claims (email, username) into the token payload
    """
    serializer = CustomTokenObtainPairSerializer(data=request.data)

    try:
        serializer.is_valid(raise_exception=True)
    except Exception as e:
        return Response(
            {'success': False, 'error': 'Invalid email or password.'},
            status=status.HTTP_401_UNAUTHORIZED
        )

    return Response(
        {'success': True, **serializer.validated_data},
        status=status.HTTP_200_OK
    )


# ─────────────────────────────────────────────────────────────────────
#  POST /api/v1/auth/refresh/
#  Public — only needs a valid refresh token
# ─────────────────────────────────────────────────────────────────────
@api_view(['POST'])
@permission_classes([AllowAny])
def refresh_token(request):
    """
    Exchange a (still-valid) refresh token for a new access token.
    Because ROTATE_REFRESH_TOKENS=True, a brand-new refresh token
    is also issued and the old one is blacklisted.

    Request body:
        { "refresh": "<refresh_token>" }

    Response:
        { "success": true, "access": "...", "refresh": "..." }
    """
    refresh_token_str = request.data.get('refresh')
    if not refresh_token_str:
        return Response(
            {'success': False, 'error': 'Refresh token is required.'},
            status=status.HTTP_400_BAD_REQUEST
        )

    try:
        refresh = RefreshToken(refresh_token_str)
        return Response(
            {
                'success': True,
                'access':  str(refresh.access_token),
                'refresh': str(refresh),   # rotated refresh token
            },
            status=status.HTTP_200_OK
        )
    except TokenError as e:
        return Response(
            {'success': False, 'error': str(e)},
            status=status.HTTP_401_UNAUTHORIZED
        )


# ─────────────────────────────────────────────────────────────────────
#  POST /api/v1/auth/logout/
#  PROTECTED — requires valid access token
# ─────────────────────────────────────────────────────────────────────
@api_view(['POST'])
@jwt_required      # our custom decorator — validates JWT before view runs
def logout(request):
    """
    Blacklist the refresh token so it can't be used again.
    The access token will still work until it expires (60 min),
    but since refresh is blacklisted the user can't get new access tokens.

    Request body:
        { "refresh": "<refresh_token>" }

    Header:
        Authorization: Bearer <access_token>
    """
    refresh_token_str = request.data.get('refresh')
    if not refresh_token_str:
        return Response(
            {'success': False, 'error': 'Refresh token is required.'},
            status=status.HTTP_400_BAD_REQUEST
        )

    try:
        token = RefreshToken(refresh_token_str)
        token.blacklist()   # adds to OutstandingToken + BlacklistedToken tables
        return Response(
            {'success': True, 'message': 'Logged out successfully.'},
            status=status.HTTP_200_OK
        )
    except TokenError as e:
        return Response(
            {'success': False, 'error': str(e)},
            status=status.HTTP_400_BAD_REQUEST
        )


# ─────────────────────────────────────────────────────────────────────
#  GET  /api/v1/auth/me/       — get my profile
#  PUT  /api/v1/auth/me/       — update my profile
#  PROTECTED — requires valid access token
# ─────────────────────────────────────────────────────────────────────
@api_view(['GET', 'PUT', 'PATCH'])
@jwt_required
def me(request):
    """
    GET  → return the authenticated user's profile
    PUT  → update the profile (full update)
    PATCH → partial update

    Header:
        Authorization: Bearer <access_token>
    """
    if request.method == 'GET':
        serializer = UserSerializer(request.user)
        return Response({'success': True, 'user': serializer.data})

    # PUT or PATCH
    partial    = request.method == 'PATCH'
    serializer = UserSerializer(request.user, data=request.data, partial=partial)

    if not serializer.is_valid():
        return Response(
            {'success': False, 'errors': serializer.errors},
            status=status.HTTP_400_BAD_REQUEST
        )

    serializer.save()
    return Response({'success': True, 'user': serializer.data})


# ─────────────────────────────────────────────────────────────────────
#  POST /api/v1/auth/change-password/
#  PROTECTED — requires valid access token
# ─────────────────────────────────────────────────────────────────────
@api_view(['POST'])
@jwt_required
def change_password(request):
    """
    Change the authenticated user's password.

    Request body:
        { "current_password": "...", "new_password": "...", "confirm_password": "..." }
    """
    user             = request.user
    current_password = request.data.get('current_password', '')
    new_password     = request.data.get('new_password', '')
    confirm_password = request.data.get('confirm_password', '')

    if not user.check_password(current_password):
        return Response(
            {'success': False, 'error': 'Current password is incorrect.'},
            status=status.HTTP_400_BAD_REQUEST
        )

    if new_password != confirm_password:
        return Response(
            {'success': False, 'error': 'New passwords do not match.'},
            status=status.HTTP_400_BAD_REQUEST
        )

    if len(new_password) < 8:
        return Response(
            {'success': False, 'error': 'Password must be at least 8 characters.'},
            status=status.HTTP_400_BAD_REQUEST
        )

    user.set_password(new_password)
    user.save()

    return Response(
        {'success': True, 'message': 'Password changed. Please log in again.'},
        status=status.HTTP_200_OK
    )
