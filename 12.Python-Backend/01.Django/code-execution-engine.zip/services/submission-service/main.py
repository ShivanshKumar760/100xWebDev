from fastapi import FastAPI, HTTPException
from contextlib import asynccontextmanager
import aio_pika
import json
import os
import sys
import asyncpg
from datetime import datetime

sys.path.insert(0, "/app")
from shared.rabbitmq import get_channel, declare_language_queues, TOPIC_EXCHANGE
from shared.models import JobRecord

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:password@postgres:5432/codeexec")

db_pool = None
mq_channel = None
topic_exchange = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global db_pool, mq_channel, topic_exchange
    db_pool = await asyncpg.create_pool(DATABASE_URL)
    async with db_pool.acquire() as conn:
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                job_id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                language TEXT NOT NULL,
                code TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                timeout_seconds INT DEFAULT 10,
                memory_limit_mb INT DEFAULT 128,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                updated_at TIMESTAMPTZ DEFAULT NOW()
            )
        """)
    mq_channel = await get_channel()
    topic_exchange = await declare_language_queues(mq_channel)
    yield
    if db_pool:
        await db_pool.close()


app = FastAPI(title="Submission Service", lifespan=lifespan)


@app.get("/health")
async def health():
    return {"status": "ok", "service": "submission-service"}


@app.post("/jobs")
async def submit_job(payload: dict):
    record = JobRecord(
        user_id=payload["user_id"],
        language=payload["language"],
        code=payload["code"],
        timeout_seconds=payload.get("timeout_seconds", 10),
        memory_limit_mb=payload.get("memory_limit_mb", 128),
    )

    async with db_pool.acquire() as conn:
        await conn.execute(
            """INSERT INTO jobs (job_id, user_id, language, code, status,
               timeout_seconds, memory_limit_mb, created_at, updated_at)
               VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8)""",
            record.job_id, record.user_id, record.language, record.code,
            record.status, record.timeout_seconds, record.memory_limit_mb,
            record.created_at,
        )

    routing_key = f"job.{record.language}"
    message_body = json.dumps({
        "job_id": record.job_id,
        "user_id": record.user_id,
        "language": record.language,
        "code": record.code,
        "timeout_seconds": record.timeout_seconds,
        "memory_limit_mb": record.memory_limit_mb,
    })

    await topic_exchange.publish(
        aio_pika.Message(
            body=message_body.encode(),
            delivery_mode=aio_pika.DeliveryMode.PERSISTENT,
            content_type="application/json",
        ),
        routing_key=routing_key,
    )

    return {
        "job_id": record.job_id,
        "status": "pending",
        "language": record.language,
        "created_at": record.created_at.isoformat(),
    }
