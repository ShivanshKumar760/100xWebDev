# apps/execution/models.py
import uuid
from django.db import models
from django.conf import settings


class ExecutionResult(models.Model):
    """
    Stores the result of every code execution request sent to Judge0.
    One row per run — keeps a full history for the user.

    Judge0 status IDs:
        1  = In Queue
        2  = Processing
        3  = Accepted  (successful run)
        4  = Wrong Answer
        5  = Time Limit Exceeded
        6  = Compilation Error
        7-12 = Runtime errors (SIGSEGV, SIGFPE, etc.)
        13 = Internal Error
        14 = Exec Format Error
    """
    STATUS_CHOICES = [
        (1,  'In Queue'),
        (2,  'Processing'),
        (3,  'Accepted'),
        (4,  'Wrong Answer'),
        (5,  'Time Limit Exceeded'),
        (6,  'Compilation Error'),
        (7,  'Runtime Error (SIGSEGV)'),
        (8,  'Runtime Error (SIGXFSZ)'),
        (9,  'Runtime Error (SIGFPE)'),
        (10, 'Runtime Error (SIGABRT)'),
        (11, 'Runtime Error (NZEC)'),
        (12, 'Runtime Error (Other)'),
        (13, 'Internal Error'),
        (14, 'Exec Format Error'),
    ]

    id          = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user        = models.ForeignKey(
                      settings.AUTH_USER_MODEL,
                      on_delete=models.CASCADE,
                      related_name='executions'
                  )
    snippet     = models.ForeignKey(
                      'workspace.Snippet',
                      on_delete=models.SET_NULL,
                      null=True, blank=True,
                      related_name='executions'
                  )

    # What we sent to Judge0
    source_code  = models.TextField()
    language_id  = models.PositiveIntegerField()   # Judge0 language ID
    stdin        = models.TextField(blank=True)

    # What Judge0 returned
    judge0_token  = models.CharField(max_length=100, blank=True)  # Judge0 submission token
    stdout        = models.TextField(blank=True)
    stderr        = models.TextField(blank=True)
    compile_output= models.TextField(blank=True)
    message       = models.TextField(blank=True)
    status_id     = models.PositiveIntegerField(choices=STATUS_CHOICES, default=1)
    status_desc   = models.CharField(max_length=50, blank=True)

    # Metrics
    time_seconds  = models.DecimalField(max_digits=6, decimal_places=3, null=True, blank=True)
    memory_kb     = models.PositiveIntegerField(null=True, blank=True)

    executed_at   = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'execution_results'
        ordering = ['-executed_at']

    def __str__(self):
        return f'Run {self.id} — status {self.status_desc} ({self.user.username})'

    @property
    def is_success(self):
        return self.status_id == 3

    @property
    def output(self):
        """Return the most relevant output string."""
        if self.stdout:
            return self.stdout
        if self.compile_output:
            return self.compile_output
        if self.stderr:
            return self.stderr
        return self.message or ''
