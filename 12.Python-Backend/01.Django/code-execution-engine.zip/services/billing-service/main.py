"""
Billing Service — consumes job.completed fanout, records usage per user.
"""
from fastapi import FastAPI
from contextlib import asynccontextmanager
import aio_pika
import asyncpg
import asyncio
import json
import os
import sys
from datetime import datetime

sys.path.insert(0, "/app")
from shared.rabbitmq import get_channel, declare_fanout_consumer_queue, QUEUE_BILLING

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:password@postgres:5432/codeexec")
db_pool = None


async def consume_billing():
    channel = await get_channel()
    await channel.set_qos(prefetch_count=10)
    queue = await declare_fanout_consumer_queue(channel, QUEUE_BILLING)

    async with queue.iterator() as q:
        async for message in q:
            async with message.process():
                event = json.loads(message.body.decode())
                try:
                    async with db_pool.acquire() as conn:
                        await conn.execute(
                            """INSERT INTO usage_records
                               (job_id, user_id, language, execution_ms, memory_used_mb, status, recorded_at)
                               VALUES ($1,$2,$3,$4,$5,$6,$7)
                               ON CONFLICT (job_id) DO NOTHING""",
                            event["job_id"], event["user_id"], event["language"],
                            event.get("execution_ms", 0), event.get("memory_used_mb", 0.0),
                            event["status"], datetime.utcnow(),
                        )
                    print(f"[billing] Recorded usage for user {event['user_id']} job {event['job_id']}")
                except Exception as e:
                    print(f"[billing] Error recording usage: {e}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    global db_pool
    db_pool = await asyncpg.create_pool(DATABASE_URL)
    async with db_pool.acquire() as conn:
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS usage_records (
                id SERIAL PRIMARY KEY,
                job_id TEXT UNIQUE NOT NULL,
                user_id TEXT NOT NULL,
                language TEXT NOT NULL,
                execution_ms INT DEFAULT 0,
                memory_used_mb FLOAT DEFAULT 0,
                status TEXT NOT NULL,
                recorded_at TIMESTAMPTZ DEFAULT NOW()
            )
        """)
    asyncio.create_task(consume_billing())
    yield
    if db_pool:
        await db_pool.close()


app = FastAPI(title="Billing Service", lifespan=lifespan)


@app.get("/health")
async def health():
    return {"status": "ok", "service": "billing-service"}


@app.get("/usage/{user_id}")
async def get_usage(user_id: str):
    async with db_pool.acquire() as conn:
        rows = await conn.fetch(
            """SELECT language,
                      COUNT(*) as total_jobs,
                      SUM(execution_ms) as total_execution_ms,
                      SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) as successful_jobs
               FROM usage_records WHERE user_id=$1 GROUP BY language""",
            user_id,
        )
    return {
        "user_id": user_id,
        "usage": [dict(r) for r in rows],
    }
