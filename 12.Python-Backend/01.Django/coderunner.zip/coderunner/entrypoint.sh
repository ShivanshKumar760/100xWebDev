#!/bin/sh
# entrypoint.sh
# Runs inside the container before Gunicorn starts.
# Order matters: wait for DB → migrate → seed → collectstatic → start server

set -e   # exit immediately on any error

echo "─────────────────────────────────────────"
echo " CodeRunner Backend — Starting up"
echo "─────────────────────────────────────────"

# ── 1. Wait for PostgreSQL to be ready ───────────────────────
echo "⏳ Waiting for PostgreSQL..."
until python -c "
import sys, psycopg2, os
try:
    psycopg2.connect(
        dbname=os.environ['DB_NAME'],
        user=os.environ['DB_USER'],
        password=os.environ['DB_PASSWORD'],
        host=os.environ['DB_HOST'],
        port=os.environ['DB_PORT'],
    )
    sys.exit(0)
except Exception:
    sys.exit(1)
"; do
    echo "  PostgreSQL not ready yet — retrying in 2s..."
    sleep 2
done
echo "✅ PostgreSQL is ready."

# ── 2. Apply database migrations ─────────────────────────────
echo "⏳ Running migrations..."
python manage.py migrate --noinput
echo "✅ Migrations done."

# ── 3. Seed languages (idempotent — safe to run every time) ──
echo "⏳ Seeding languages..."
python manage.py seed_languages
echo "✅ Languages seeded."

# ── 4. Collect static files ──────────────────────────────────
echo "⏳ Collecting static files..."
python manage.py collectstatic --noinput
echo "✅ Static files collected."

echo "─────────────────────────────────────────"
echo " Starting Gunicorn on 0.0.0.0:8000"
echo "─────────────────────────────────────────"

# ── 5. Start Gunicorn ─────────────────────────────────────────
# --workers: (2 × CPU cores) + 1 is a common formula
# --timeout: kill a worker if it hangs for 120s
exec gunicorn coderunner.wsgi:application \
    --bind 0.0.0.0:8000 \
    --workers 3 \
    --timeout 120 \
    --access-logfile - \
    --error-logfile  -
