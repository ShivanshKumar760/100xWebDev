# apps/execution/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('run/',              views.run_code,          name='execution-run'),
    path('history/',          views.execution_history,  name='execution-history'),
    path('stats/',            views.execution_stats,    name='execution-stats'),
    path('<uuid:execution_id>/', views.execution_detail, name='execution-detail'),
]
