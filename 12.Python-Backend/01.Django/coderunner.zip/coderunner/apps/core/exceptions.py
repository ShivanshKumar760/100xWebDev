# apps/core/exceptions.py
from rest_framework.views import exception_handler
from rest_framework.response import Response
from rest_framework import status


def custom_exception_handler(exc, context):
    """
    Wraps every error response in a consistent shape:
    { "success": false, "error": "...", "detail": {...} }
    """
    response = exception_handler(exc, context)

    if response is not None:
        error_data = {
            'success': False,
            'error':   str(exc),
            'detail':  response.data,
        }
        response.data = error_data

    return response
