# apps/workspace/management/commands/seed_languages.py
#
# Run: python manage.py seed_languages
# Seeds the Language table with the most common Judge0 language IDs.
# You can also call judge0.get_languages() to fetch the full live list.

from django.core.management.base import BaseCommand
from apps.workspace.models import Language


LANGUAGES = [
    {'name': 'Python 3 (3.8.1)',       'slug': 'python3',     'judge0_id': 71,  'version': '3.8.1'},
    {'name': 'JavaScript (Node.js)',    'slug': 'javascript',  'judge0_id': 63,  'version': '12.14.0'},
    {'name': 'TypeScript',             'slug': 'typescript',  'judge0_id': 74,  'version': '3.7.4'},
    {'name': 'Java (OpenJDK 13)',       'slug': 'java',        'judge0_id': 62,  'version': '13.0.1'},
    {'name': 'C++ (GCC 9.2)',          'slug': 'cpp',         'judge0_id': 54,  'version': 'GCC 9.2'},
    {'name': 'C (GCC 9.2)',            'slug': 'c',           'judge0_id': 50,  'version': 'GCC 9.2'},
    {'name': 'Go (1.13.5)',            'slug': 'go',          'judge0_id': 60,  'version': '1.13.5'},
    {'name': 'Rust (1.40.0)',          'slug': 'rust',        'judge0_id': 73,  'version': '1.40.0'},
    {'name': 'Ruby (2.7.0)',           'slug': 'ruby',        'judge0_id': 72,  'version': '2.7.0'},
    {'name': 'PHP (7.4.1)',            'slug': 'php',         'judge0_id': 68,  'version': '7.4.1'},
    {'name': 'C# (Mono 6.6)',          'slug': 'csharp',      'judge0_id': 51,  'version': 'Mono 6.6'},
    {'name': 'Swift (5.2.3)',          'slug': 'swift',       'judge0_id': 83,  'version': '5.2.3'},
    {'name': 'Kotlin (1.3.70)',        'slug': 'kotlin',      'judge0_id': 78,  'version': '1.3.70'},
    {'name': 'Bash (5.0.0)',           'slug': 'bash',        'judge0_id': 46,  'version': '5.0.0'},
    {'name': 'SQL (SQLite 3.27.2)',    'slug': 'sql',         'judge0_id': 82,  'version': 'SQLite 3.27.2'},
]


class Command(BaseCommand):
    help = 'Seed the Language table with common Judge0 language IDs'

    def handle(self, *args, **options):
        created = 0
        updated = 0
        for lang in LANGUAGES:
            obj, was_created = Language.objects.update_or_create(
                judge0_id=lang['judge0_id'],
                defaults={
                    'name':      lang['name'],
                    'slug':      lang['slug'],
                    'version':   lang['version'],
                    'is_active': True,
                }
            )
            if was_created:
                created += 1
                self.stdout.write(self.style.SUCCESS(f'  Created: {obj.name}'))
            else:
                updated += 1
                self.stdout.write(f'  Updated: {obj.name}')

        self.stdout.write(self.style.SUCCESS(
            f'\nDone. {created} created, {updated} updated.'
        ))
