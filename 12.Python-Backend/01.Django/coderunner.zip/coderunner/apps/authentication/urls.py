# apps/authentication/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('register/',        views.register,         name='auth-register'),
    path('login/',           views.login,             name='auth-login'),
    path('refresh/',         views.refresh_token,     name='auth-refresh'),
    path('logout/',          views.logout,            name='auth-logout'),
    path('me/',              views.me,                name='auth-me'),
    path('change-password/', views.change_password,   name='auth-change-password'),
]
