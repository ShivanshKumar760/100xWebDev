"""
Notifier Service — consumes job.completed fanout, pushes results to
connected WebSocket clients.
"""
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from contextlib import asynccontextmanager
import aio_pika
import asyncio
import json
import sys
from typing import Dict, Set

sys.path.insert(0, "/app")
from shared.rabbitmq import get_channel, declare_fanout_consumer_queue, QUEUE_NOTIFIER

# Map of user_id -> set of active WebSocket connections
_connections: Dict[str, Set[WebSocket]] = {}


class ConnectionManager:
    def register(self, user_id: str, ws: WebSocket):
        _connections.setdefault(user_id, set()).add(ws)

    def unregister(self, user_id: str, ws: WebSocket):
        _connections.get(user_id, set()).discard(ws)

    async def broadcast_to_user(self, user_id: str, data: dict):
        dead = set()
        for ws in _connections.get(user_id, set()):
            try:
                await ws.send_json(data)
            except Exception:
                dead.add(ws)
        for ws in dead:
            _connections.get(user_id, set()).discard(ws)


manager = ConnectionManager()


async def consume_notifications():
    channel = await get_channel()
    await channel.set_qos(prefetch_count=10)
    queue = await declare_fanout_consumer_queue(channel, QUEUE_NOTIFIER)

    async with queue.iterator() as q:
        async for message in q:
            async with message.process():
                event = json.loads(message.body.decode())
                user_id = event.get("user_id", "anonymous")
                await manager.broadcast_to_user(user_id, {
                    "type": "job.completed",
                    "job_id": event["job_id"],
                    "status": event["status"],
                    "stdout": event.get("stdout", ""),
                    "stderr": event.get("stderr", ""),
                    "exit_code": event.get("exit_code", 0),
                    "execution_ms": event.get("execution_ms", 0),
                })
                print(f"[notifier] Pushed result to user {user_id} for job {event['job_id']}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    asyncio.create_task(consume_notifications())
    yield


app = FastAPI(title="Notifier Service", lifespan=lifespan)


@app.get("/health")
async def health():
    return {"status": "ok", "service": "notifier-service"}


@app.websocket("/ws/{user_id}")
async def websocket_endpoint(websocket: WebSocket, user_id: str):
    await websocket.accept()
    manager.register(user_id, websocket)
    print(f"[notifier] WS connected: {user_id}")
    try:
        while True:
            await websocket.receive_text()  # keep connection alive
    except WebSocketDisconnect:
        manager.unregister(user_id, websocket)
        print(f"[notifier] WS disconnected: {user_id}")
