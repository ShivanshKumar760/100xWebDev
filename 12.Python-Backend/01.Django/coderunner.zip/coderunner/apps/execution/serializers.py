# apps/execution/serializers.py
from rest_framework import serializers
from .models import ExecutionResult


class ExecuteRequestSerializer(serializers.Serializer):
    """
    Validates the incoming run request from Postman / React.
    Either source_code + language_id (ad-hoc run)
    OR snippet_id (run a saved snippet).
    """
    source_code = serializers.CharField(required=False, allow_blank=False)
    language_id = serializers.IntegerField(required=False)
    stdin       = serializers.CharField(required=False, allow_blank=True, default='')
    snippet_id  = serializers.UUIDField(required=False)

    def validate(self, data):
        has_snippet = bool(data.get('snippet_id'))
        has_code    = bool(data.get('source_code')) and bool(data.get('language_id'))

        if not has_snippet and not has_code:
            raise serializers.ValidationError(
                'Provide either snippet_id OR both source_code and language_id.'
            )
        return data


class ExecutionResultSerializer(serializers.ModelSerializer):
    is_success = serializers.ReadOnlyField()
    output     = serializers.ReadOnlyField()

    class Meta:
        model  = ExecutionResult
        fields = [
            'id', 'snippet', 'source_code', 'language_id', 'stdin',
            'judge0_token', 'stdout', 'stderr', 'compile_output',
            'message', 'status_id', 'status_desc',
            'time_seconds', 'memory_kb',
            'is_success', 'output', 'executed_at',
        ]
        read_only_fields = fields
