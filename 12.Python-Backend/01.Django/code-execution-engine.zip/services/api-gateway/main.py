from fastapi import FastAPI, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from typing import Optional
import httpx
import os
import time
from collections import defaultdict
import sys

sys.path.insert(0, "/app")
from shared.models import JobSubmitRequest

app = FastAPI(title="API Gateway", description="Auth · rate-limiting · routing")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

SUBMISSION_URL = os.getenv("SUBMISSION_SERVICE_URL", "http://submission-service:8001")
RESULT_URL = os.getenv("RESULT_SERVICE_URL", "http://result-service:8002")

_rate_store: dict[str, list[float]] = defaultdict(list)
RATE_LIMIT = 20
RATE_WINDOW = 60


def check_rate_limit(user_id: str):
    now = time.time()
    _rate_store[user_id] = [t for t in _rate_store[user_id] if now - t < RATE_WINDOW]
    if len(_rate_store[user_id]) >= RATE_LIMIT:
        raise HTTPException(429, "Rate limit exceeded (20 req/min)")
    _rate_store[user_id].append(now)


def extract_user(authorization: Optional[str]) -> str:
    if authorization and authorization.startswith("Bearer "):
        return authorization.split(" ", 1)[1]
    return "anonymous"


@app.get("/health")
async def health():
    return {"status": "ok", "service": "api-gateway"}


@app.post("/api/v1/jobs")
async def submit_job(
    payload: JobSubmitRequest,
    authorization: Optional[str] = Header(default=None),
):
    user_id = extract_user(authorization)
    check_rate_limit(user_id)
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            f"{SUBMISSION_URL}/jobs",
            json={**payload.dict(), "user_id": user_id},
            timeout=10,
        )
    if resp.status_code != 200:
        raise HTTPException(resp.status_code, resp.text)
    return resp.json()


@app.get("/api/v1/jobs/{job_id}")
async def get_job(
    job_id: str,
    authorization: Optional[str] = Header(default=None),
):
    async with httpx.AsyncClient() as client:
        resp = await client.get(f"{RESULT_URL}/jobs/{job_id}", timeout=10)
    if resp.status_code == 404:
        raise HTTPException(404, "Job not found")
    return resp.json()
