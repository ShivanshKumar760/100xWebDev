# apps/execution/judge0.py
#
# This module is the single place that talks to the Judge0 API.
# Views never call requests.post() directly — they call functions here.
# This makes it easy to swap Judge0 for another service later.

import base64
import requests
from django.conf import settings


# ─────────────────────────────────────────────────────────────────────
#  Judge0 API constants
# ─────────────────────────────────────────────────────────────────────
BASE_URL = settings.JUDGE0_API_URL    # e.g. https://judge0-ce.p.rapidapi.com
HEADERS  = {
    'X-RapidAPI-Key':  settings.JUDGE0_API_KEY,
    'X-RapidAPI-Host': settings.JUDGE0_API_HOST,
    'Content-Type':    'application/json',
}

# How long to wait for Judge0 to respond (seconds)
REQUEST_TIMEOUT = 15


# ─────────────────────────────────────────────────────────────────────
#  Helper: base64 encode / decode
#  Judge0 requires source code and stdin to be base64-encoded
# ─────────────────────────────────────────────────────────────────────
def _b64_encode(text: str) -> str:
    return base64.b64encode(text.encode()).decode()

def _b64_decode(text: str) -> str:
    if not text:
        return ''
    try:
        return base64.b64decode(text.encode()).decode(errors='replace')
    except Exception:
        return text


# ─────────────────────────────────────────────────────────────────────
#  SUBMIT  — send code to Judge0, get back a token
#
#  Judge0 is asynchronous by default:
#    1. You POST the code → Judge0 gives you a token
#    2. You GET /submissions/<token> to poll for the result
#
#  OR use ?wait=true to make it synchronous (blocks until done).
#  We use wait=true for simplicity in this project.
# ─────────────────────────────────────────────────────────────────────
def submit_code(source_code: str, language_id: int, stdin: str = '') -> dict:
    """
    Submit source code to Judge0 and wait for the result.

    Args:
        source_code:  The program source code (plain text)
        language_id:  Judge0's integer ID for the language (e.g. 71 = Python 3)
        stdin:        Optional standard input for the program

    Returns:
        dict with keys: token, stdout, stderr, compile_output,
                        message, status, time, memory
    """
    payload = {
        'source_code': _b64_encode(source_code),
        'language_id': language_id,
        'stdin':       _b64_encode(stdin) if stdin else '',
        'base64_encoded': True,   # tell Judge0 our payload is base64
    }

    try:
        response = requests.post(
            f'{BASE_URL}/submissions',
            json=payload,
            headers=HEADERS,
            params={'base64_encoded': 'true', 'wait': 'true'},
            timeout=REQUEST_TIMEOUT,
        )
        response.raise_for_status()
        data = response.json()

        return _normalise_response(data)

    except requests.exceptions.Timeout:
        return _error_response('Judge0 request timed out. Please try again.')
    except requests.exceptions.ConnectionError:
        return _error_response('Could not connect to Judge0. Check your API key.')
    except requests.exceptions.HTTPError as e:
        return _error_response(f'Judge0 API error: {e.response.status_code} — {e.response.text}')
    except Exception as e:
        return _error_response(f'Unexpected error: {str(e)}')


# ─────────────────────────────────────────────────────────────────────
#  POLL  — for async flow: check status of a previous submission
# ─────────────────────────────────────────────────────────────────────
def get_submission(token: str) -> dict:
    """
    Fetch the result of a previous submission by its token.
    Used when you submitted without wait=true.
    """
    try:
        response = requests.get(
            f'{BASE_URL}/submissions/{token}',
            headers=HEADERS,
            params={'base64_encoded': 'true'},
            timeout=REQUEST_TIMEOUT,
        )
        response.raise_for_status()
        return _normalise_response(response.json())
    except Exception as e:
        return _error_response(str(e))


# ─────────────────────────────────────────────────────────────────────
#  LANGUAGES — fetch supported languages from Judge0
# ─────────────────────────────────────────────────────────────────────
def get_languages() -> list:
    """Returns list of dicts: [{id, name}, ...]"""
    try:
        response = requests.get(
            f'{BASE_URL}/languages',
            headers=HEADERS,
            timeout=REQUEST_TIMEOUT,
        )
        response.raise_for_status()
        return response.json()
    except Exception:
        return []


# ─────────────────────────────────────────────────────────────────────
#  Internal helpers
# ─────────────────────────────────────────────────────────────────────
def _normalise_response(data: dict) -> dict:
    """
    Judge0 returns base64-encoded fields. Decode them all and
    return a clean, consistent dict regardless of Judge0's schema.
    """
    status = data.get('status', {}) or {}
    return {
        'token':          data.get('token', ''),
        'stdout':         _b64_decode(data.get('stdout', '') or ''),
        'stderr':         _b64_decode(data.get('stderr', '') or ''),
        'compile_output': _b64_decode(data.get('compile_output', '') or ''),
        'message':        _b64_decode(data.get('message', '') or ''),
        'status_id':      status.get('id', 13),
        'status_desc':    status.get('description', 'Internal Error'),
        'time':           data.get('time'),    # seconds as string e.g. "0.045"
        'memory':         data.get('memory'),  # KB as integer
        'success':        status.get('id') == 3,   # 3 = Accepted
    }


def _error_response(message: str) -> dict:
    return {
        'token':          '',
        'stdout':         '',
        'stderr':         message,
        'compile_output': '',
        'message':        message,
        'status_id':      13,
        'status_desc':    'Internal Error',
        'time':           None,
        'memory':         None,
        'success':        False,
    }
