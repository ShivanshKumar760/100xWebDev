# coderunner/urls.py
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),

    # All API routes live under /api/v1/
    path('api/v1/auth/',      include('apps.authentication.urls')),
    path('api/v1/workspace/', include('apps.workspace.urls')),
    path('api/v1/execution/', include('apps.execution.urls')),
]
