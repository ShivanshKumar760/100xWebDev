"""
Executor Worker — consumes from a language queue, runs code in a subprocess
sandbox (resource-limited), publishes result to the fanout exchange.
"""
import asyncio
import aio_pika
import json
import os
import sys
import resource
import subprocess
import time
from datetime import datetime

sys.path.insert(0, "/app")
from shared.rabbitmq import (
    get_channel,
    declare_language_queues,
    declare_fanout_exchange,
    QUEUE_PYTHON, QUEUE_JS, QUEUE_CPP,
)

LANGUAGE = os.getenv("WORKER_LANGUAGE", "python")  # python | js | cpp

LANGUAGE_QUEUE_MAP = {
    "python": QUEUE_PYTHON,
    "js": QUEUE_JS,
    "cpp": QUEUE_CPP,
}

LANGUAGE_CMD_MAP = {
    "python": lambda path: ["python3", path],
    "js": lambda path: ["node", path],
    "cpp": lambda path, bin_path: [bin_path],
}

FILE_EXT = {"python": ".py", "js": ".js", "cpp": ".cpp"}


def run_code_subprocess(language: str, code: str, timeout: int, memory_mb: int):
    import tempfile, os

    ext = FILE_EXT[language]
    start = time.monotonic()

    with tempfile.NamedTemporaryFile(suffix=ext, mode="w", delete=False) as f:
        f.write(code)
        code_path = f.name

    bin_path = None
    try:
        if language == "cpp":
            bin_path = code_path.replace(".cpp", "")
            compile_result = subprocess.run(
                ["g++", "-O2", "-o", bin_path, code_path],
                capture_output=True, text=True, timeout=15
            )
            if compile_result.returncode != 0:
                return {
                    "stdout": "",
                    "stderr": compile_result.stderr,
                    "exit_code": compile_result.returncode,
                    "execution_ms": 0,
                    "memory_used_mb": 0.0,
                    "status": "failed",
                }
            cmd = [bin_path]
        elif language == "python":
            cmd = ["python3", code_path]
        else:
            cmd = ["node", code_path]

        def limit_resources():
            mem_bytes = memory_mb * 1024 * 1024
            resource.setrlimit(resource.RLIMIT_AS, (mem_bytes, mem_bytes))
            resource.setrlimit(resource.RLIMIT_NPROC, (50, 50))

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            preexec_fn=limit_resources,
        )
        elapsed_ms = int((time.monotonic() - start) * 1000)
        return {
            "stdout": result.stdout[:8192],
            "stderr": result.stderr[:2048],
            "exit_code": result.returncode,
            "execution_ms": elapsed_ms,
            "memory_used_mb": 0.0,
            "status": "completed" if result.returncode == 0 else "failed",
        }
    except subprocess.TimeoutExpired:
        return {
            "stdout": "", "stderr": "Execution timed out",
            "exit_code": -1, "execution_ms": timeout * 1000,
            "memory_used_mb": 0.0, "status": "timeout",
        }
    except Exception as e:
        return {
            "stdout": "", "stderr": str(e),
            "exit_code": -1, "execution_ms": 0,
            "memory_used_mb": 0.0, "status": "failed",
        }
    finally:
        try:
            os.unlink(code_path)
            if bin_path and os.path.exists(bin_path):
                os.unlink(bin_path)
        except Exception:
            pass


async def process_message(message: aio_pika.IncomingMessage, fanout_exchange: aio_pika.Exchange):
    async with message.process():
        job = json.loads(message.body.decode())
        print(f"[worker:{LANGUAGE}] Processing job {job['job_id']}")

        exec_result = await asyncio.get_event_loop().run_in_executor(
            None,
            run_code_subprocess,
            job["language"],
            job["code"],
            job.get("timeout_seconds", 10),
            job.get("memory_limit_mb", 128),
        )

        result_payload = {
            "job_id": job["job_id"],
            "user_id": job["user_id"],
            "language": job["language"],
            "timestamp": datetime.utcnow().isoformat(),
            **exec_result,
        }

        await fanout_exchange.publish(
            aio_pika.Message(
                body=json.dumps(result_payload).encode(),
                delivery_mode=aio_pika.DeliveryMode.PERSISTENT,
                content_type="application/json",
            ),
            routing_key="",  # fanout ignores routing key
        )
        print(f"[worker:{LANGUAGE}] Published result for {job['job_id']} -> {exec_result['status']}")


async def main():
    queue_name = LANGUAGE_QUEUE_MAP[LANGUAGE]
    print(f"[worker:{LANGUAGE}] Starting, consuming from '{queue_name}'")

    channel = await get_channel()
    await channel.set_qos(prefetch_count=1)

    await declare_language_queues(channel)
    fanout_exchange = await declare_fanout_exchange(channel)

    queue = await channel.declare_queue(queue_name, durable=True)

    async with queue.iterator() as q:
        async for message in q:
            await process_message(message, fanout_exchange)


if __name__ == "__main__":
    asyncio.run(main())
