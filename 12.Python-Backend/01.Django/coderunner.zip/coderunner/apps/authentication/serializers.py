# apps/authentication/serializers.py
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from django.contrib.auth import get_user_model

User = get_user_model()


# ─────────────────────────────────────────────────────────────────────
#  REGISTRATION
# ─────────────────────────────────────────────────────────────────────
class RegisterSerializer(serializers.ModelSerializer):
    password         = serializers.CharField(write_only=True, min_length=8)
    confirm_password = serializers.CharField(write_only=True)

    class Meta:
        model  = User
        fields = ['email', 'username', 'first_name', 'last_name',
                  'password', 'confirm_password']

    def validate(self, data):
        if data['password'] != data['confirm_password']:
            raise serializers.ValidationError({'confirm_password': 'Passwords do not match.'})
        return data

    def create(self, validated_data):
        validated_data.pop('confirm_password')
        # create_user handles password hashing
        return User.objects.create_user(**validated_data)


# ─────────────────────────────────────────────────────────────────────
#  USER PROFILE (read + update)
# ─────────────────────────────────────────────────────────────────────
class UserSerializer(serializers.ModelSerializer):
    full_name = serializers.ReadOnlyField()

    class Meta:
        model  = User
        fields = ['id', 'email', 'username', 'first_name', 'last_name',
                  'full_name', 'avatar_url', 'bio', 'date_joined']
        read_only_fields = ['id', 'email', 'date_joined']


# ─────────────────────────────────────────────────────────────────────
#  CUSTOM JWT TOKEN  — add extra claims to the payload
# ─────────────────────────────────────────────────────────────────────
class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    """
    Adds user info directly inside the JWT payload so the client
    doesn't need to make a separate /me request on login.

    The access token payload will look like:
    {
      "token_type": "access",
      "exp": 1234567890,
      "iat": 1234567890,
      "jti": "abc123...",
      "user_id": "uuid...",
      "email": "user@example.com",
      "username": "john",
      "is_staff": false
    }
    """
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)

        # Add custom claims — these are embedded in the token
        token['email']    = user.email
        token['username'] = user.username
        token['is_staff'] = user.is_staff

        return token

    def validate(self, attrs):
        data = super().validate(attrs)

        # Also return user profile data in the response body
        data['user'] = UserSerializer(self.user).data
        return data
