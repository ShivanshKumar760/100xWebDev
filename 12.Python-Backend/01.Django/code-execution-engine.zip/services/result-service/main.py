"""
Result Service — consumes job.completed fanout, writes to PostgreSQL + Redis,
exposes REST endpoint for job status polling.
"""
from fastapi import FastAPI, HTTPException
from contextlib import asynccontextmanager
import aio_pika
import asyncpg
import redis.asyncio as aioredis
import json
import os
import sys
import asyncio
from datetime import datetime

sys.path.insert(0, "/app")
from shared.rabbitmq import get_channel, declare_fanout_consumer_queue, QUEUE_RESULT

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:password@postgres:5432/codeexec")
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379")
RESULT_TTL = 3600  # 1 hour

db_pool = None
redis_client = None


async def consume_results():
    channel = await get_channel()
    await channel.set_qos(prefetch_count=5)
    queue = await declare_fanout_consumer_queue(channel, QUEUE_RESULT)

    async with queue.iterator() as q:
        async for message in q:
            async with message.process():
                event = json.loads(message.body.decode())
                job_id = event["job_id"]
                try:
                    async with db_pool.acquire() as conn:
                        await conn.execute(
                            """UPDATE jobs SET status=$1, updated_at=NOW() WHERE job_id=$2""",
                            event["status"], job_id,
                        )
                        await conn.execute(
                            """INSERT INTO job_results
                               (job_id, stdout, stderr, exit_code, execution_ms, memory_used_mb, status, completed_at)
                               VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
                               ON CONFLICT (job_id) DO UPDATE
                               SET stdout=EXCLUDED.stdout, stderr=EXCLUDED.stderr,
                                   exit_code=EXCLUDED.exit_code, status=EXCLUDED.status""",
                            job_id, event.get("stdout",""), event.get("stderr",""),
                            event.get("exit_code",0), event.get("execution_ms",0),
                            event.get("memory_used_mb",0.0), event["status"],
                            datetime.utcnow(),
                        )
                    await redis_client.setex(
                        f"result:{job_id}", RESULT_TTL, json.dumps(event)
                    )
                    print(f"[result-service] Stored result for {job_id}")
                except Exception as e:
                    print(f"[result-service] Error storing {job_id}: {e}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    global db_pool, redis_client
    db_pool = await asyncpg.create_pool(DATABASE_URL)
    redis_client = aioredis.from_url(REDIS_URL)

    async with db_pool.acquire() as conn:
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                job_id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                language TEXT NOT NULL,
                code TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                timeout_seconds INT DEFAULT 10,
                memory_limit_mb INT DEFAULT 128,
                created_at TIMESTAMPTZ DEFAULT NOW(),
                updated_at TIMESTAMPTZ DEFAULT NOW()
            )
        """)
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS job_results (
                job_id TEXT PRIMARY KEY,
                stdout TEXT DEFAULT '',
                stderr TEXT DEFAULT '',
                exit_code INT DEFAULT 0,
                execution_ms INT DEFAULT 0,
                memory_used_mb FLOAT DEFAULT 0,
                status TEXT NOT NULL,
                completed_at TIMESTAMPTZ DEFAULT NOW()
            )
        """)

    asyncio.create_task(consume_results())
    yield
    if db_pool:
        await db_pool.close()
    if redis_client:
        await redis_client.close()


app = FastAPI(title="Result Service", lifespan=lifespan)


@app.get("/health")
async def health():
    return {"status": "ok", "service": "result-service"}


@app.get("/jobs/{job_id}")
async def get_job(job_id: str):
    cached = await redis_client.get(f"result:{job_id}")
    if cached:
        return {**json.loads(cached), "source": "cache"}

    async with db_pool.acquire() as conn:
        row = await conn.fetchrow(
            """SELECT j.job_id, j.user_id, j.language, j.status, j.created_at,
                      r.stdout, r.stderr, r.exit_code, r.execution_ms, r.completed_at
               FROM jobs j LEFT JOIN job_results r ON j.job_id = r.job_id
               WHERE j.job_id = $1""",
            job_id,
        )
    if not row:
        raise HTTPException(404, "Job not found")

    return {
        "job_id": row["job_id"],
        "user_id": row["user_id"],
        "language": row["language"],
        "status": row["status"],
        "created_at": row["created_at"].isoformat() if row["created_at"] else None,
        "completed_at": row["completed_at"].isoformat() if row["completed_at"] else None,
        "stdout": row["stdout"] or "",
        "stderr": row["stderr"] or "",
        "exit_code": row["exit_code"],
        "execution_ms": row["execution_ms"],
        "source": "db",
    }
